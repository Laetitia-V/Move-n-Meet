<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet"	href="styles/Style.css"	type="text/css"	
media="screen"	/>	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
	<title>MovenMeet</title>
<?php		
			session_start();	
			session_destroy();	
			echo "<meta http-equiv='refresh' content='0; URL=pageA.php'>" ;
	 	?>	



</head>
<body>
	

</body>
</html>